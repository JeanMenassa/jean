const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express()
const port = 3000

let contacts = [{
    "ID": "001",
    "Name": "Marc Issa",
    "Profession": "Doctor",
    "Mobile_number": "03123456",
    "Telephone_number": "01879126",
},
{
    "ID": "002",
    "Name": "Ahmad Khaled",
    "Profession": "Farmer",
    "Mobile_number": "76290365",
    "Telephone_number": "04321888",
},
{
    "ID": "003",
    "Name": "Ali Sibai",
    "Profession": "Civil Engineer",
    "Mobile_number": "03773564",
    "Telephone_number": "06632457",
}];

app.use(cors());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/contact', (req, res) => {
    const contact = req.body;
    console.log(contact);
    contacts.push(contact);

    res.send('Contact has been added to the database');
});

app.get('/contact', (req, res) => {
    res.json(contacts);
});

app.get('/contact/:id', (req, res) => {
    const id = req.params.id;
    for (let contact of contacts) {
        if (contact.ID === id) {
            res.json(contact);
            return;
        }
    }
    res.status(404).send('Contact not found');
});

app.delete('/contact/:id', (req, res) => {
    const id = req.params.id;
    contacts = contacts.filter(i => {
        if (i.ID !== id) {
            console.log("Deleted successfully")
            return true;
           
        }
        
        return false;
    });
    res.send('Contact has been deleted');
});

app.post('/contact/:id', (req, res) => {
    // reading id from the URL
    const id = req.params.id;
    const newcontact = req.body;

    console.log(newcontact);
    for (let i = 0; i < contacts.length; i++) {
        let contact = contacts[i]

        if (contact.ID === id) {
            contacts[i] = newcontact;
        }
    }
    res.send('Contact has been edited');
});

app.listen(port, () => console.log(`Hello world app listening on port ${port}!`));