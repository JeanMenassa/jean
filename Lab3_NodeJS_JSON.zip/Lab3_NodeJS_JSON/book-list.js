const setEditModal = (ID)=>{

    
    let Name=document.getElementById("name-"+ID.toString()).value;
    let Profession=document.getElementById("prof-"+ID.toString()).value;
    let Mobile_number=document.getElementById("mnum-"+ID.toString()).value;
    let Telephone_number=document.getElementById("tnum-"+ID.toString()).value;
   
    let data = {};

  

        data["ID"]= ID.toString();
        data["Name"]= Name;
        data["Profession"]= Profession;
        data["Mobile_number"]= Mobile_number;
        data["Telephone_number"]= Telephone_number;
        console.log(data);

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "http://localhost:3000/contact/" + ID.toString());
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(data));
    location.reload();
}

    const deletecontact = (ID) => {
    
        const xhttp = new XMLHttpRequest();
        xhttp.open("DELETE", "http://localhost:3000/contact/" + ID.toString(), false);
        xhttp.send();
        location.reload();
    
    }
    


function loadcontacts() {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:3000/contact", false);
    xhttp.send();

    const contacts = JSON.parse(xhttp.responseText);
console.log(contacts);
    for (let contact of contacts) {
        let ID  = contact.ID.toString();    
        let x = `
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${contact.Name}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">${contact.ID}</h6>

                        <div>Profession: ${contact.Profession}</div>
                        <div>Mobile Number: ${contact.Mobile_number}</div>
                        <div>Telephone number: ${contact.Telephone_number}</div>

                        <hr>
                        


                        <button type = "button" onclick = "deletecontact(${contact.ID})" >Delete</button>
                        <button types="button" data-toggle="modal" data-target="#modifications-${contact.ID}">
                            Edit
                        </button>
                        <div class="modal fade"
        id="modifications-${contact.ID}" role="dialog">
        <div class="modal-dialog">
 
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
 
                    <h1 class="modal-title">
                        Edit Contact Information
                    </h1>
                </div>
 
                <div class="modal-body">
                     
                     
<p>
   

                <label for="name">Name:</label>         
                <input type="text" id="name-${contact.ID}" name="name" value="${contact.Name}"><br>
                <label for="prof">Profession:</label>
                <input type="text" id="prof-${contact.ID}" name="prof" value="${contact.Profession}"><br>
                <label for="mnum">Mobile Number:</label>
                <input type="text" id="mnum-${contact.ID}" name="mnum" value="${contact.Mobile_number}"><br>
                <label for="tnum">Telephone Number:</label>
                <input type="text" id="tnum-${contact.ID}" name="tnum" value="${contact.Telephone_number}"><br>


                    </p>
 
 
                </div>
 
                <div class="modal-footer">
                    <button type="button"
                        class="btn btn-primary"
                        onClick="setEditModal(${contact.ID})">
                        Modify
                    </button>
                     
                    <button type="button"
                        class="btn btn-default"
                        data-dismiss="modal"
                        >
                        Close
                    </button>
                </div>
            </div>
        
               
            </div>
        `;

        document.getElementById('contacts').innerHTML = document.getElementById('contacts').innerHTML + x;
    }
}

loadcontacts();